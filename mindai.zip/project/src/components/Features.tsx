import React from 'react';
import { MessageSquare, Phone, Clock, Lock } from 'lucide-react';

const features = [
  {
    icon: MessageSquare,
    title: 'AI Chat Therapy',
    description: 'Connect instantly with our AI therapist for personalized support and guidance.',
    bgImage: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80'
  },
  {
    icon: Phone,
    title: 'Real-Time AI Voice Calling',
    description: 'Experience natural conversations with our advanced AI voice technology.',
    bgImage: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80'
  },
  {
    icon: Clock,
    title: '24/7 Support',
    description: 'Access therapeutic support whenever you need it, day or night.',
    bgImage: 'https://images.unsplash.com/photo-1558346490-a72e53ae2d4f?auto=format&fit=crop&q=80'
  },
  {
    icon: Lock,
    title: 'Secure Sessions',
    description: 'Your privacy and data security are our top priorities.',
    bgImage: 'https://images.unsplash.com/photo-1639322537228-f710d846310a?auto=format&fit=crop&q=80'
  },
];

export const Features = () => {
  return (
    <section id="features" className="py-24 bg-gray-900">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-bold text-center mb-16 gradient-text">
          Transformative Features
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div
                key={index}
                className="group relative overflow-hidden rounded-2xl"
              >
                {/* Background Image */}
                <div 
                  className="absolute inset-0 transition-transform duration-500 group-hover:scale-110"
                  style={{
                    backgroundImage: `url('${feature.bgImage}')`,
                    backgroundSize: 'cover',
                    backgroundPosition: 'center',
                  }}
                >
                  <div className="absolute inset-0 bg-gray-900/80 backdrop-blur-sm" />
                </div>

                <div className="relative p-8 glass-card h-full">
                  <div className="relative mb-6">
                    <div className="w-16 h-16 rounded-xl bg-gray-800/60 flex items-center justify-center group-hover:bg-gray-700/60 transition-colors duration-300">
                      <Icon className="w-8 h-8 text-purple-400" />
                    </div>
                    <div className="absolute -inset-2 bg-purple-500/20 rounded-xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  </div>
                  
                  <h3 className="text-xl font-semibold mb-3 text-white">
                    {feature.title}
                  </h3>
                  <p className="text-gray-300">
                    {feature.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};