import React from 'react';
import { UserPlus, Globe, Heart } from 'lucide-react';

const steps = [
  {
    icon: UserPlus,
    title: 'Sign Up',
    description: 'Create your account and tell us about your needs.',
  },
  {
    icon: Globe,
    title: 'Connect',
    description: 'Get matched with our AI therapy system.',
  },
  {
    icon: Heart,
    title: 'Heal',
    description: 'Begin your journey to better mental health.',
  },
];

export const HowItWorks = () => {
  return (
    <section id="how-it-works" className="py-24 relative overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1581090700227-2fac2c939d85?auto=format&fit=crop&q=80')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="absolute inset-0 bg-gray-900/90 backdrop-blur-sm" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <h2 className="text-4xl font-bold text-center mb-16 gradient-text">
          How It Works
        </h2>

        <div className="relative">
          <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-purple-500/20 -translate-y-1/2 hidden lg:block" />
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <div key={index} className="relative group">
                  <div className="flex flex-col items-center text-center">
                    <div className="relative mb-8">
                      <div className="w-20 h-20 rounded-full bg-gray-800/60 flex items-center justify-center group-hover:bg-gray-700/60 transition-colors duration-300">
                        <Icon className="w-10 h-10 text-purple-400" />
                      </div>
                      <div className="absolute -inset-4 bg-purple-500/20 rounded-full blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    </div>
                    
                    <div className="glass-card p-6 rounded-xl">
                      <h3 className="text-2xl font-semibold mb-4 text-white">
                        {step.title}
                      </h3>
                      <p className="text-gray-300">
                        {step.description}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};