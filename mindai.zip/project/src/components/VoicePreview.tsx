import React from 'react';
import { Phone, Wand2 } from 'lucide-react';

export const VoicePreview = () => {
  return (
    <section id="voice-preview" className="py-24 relative overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1620712943543-bcc4688e7485?auto=format&fit=crop&q=80')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="absolute inset-0 bg-gray-900/90 backdrop-blur-sm" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <div className="relative mb-8">
            <div className="w-20 h-20 mx-auto rounded-full bg-gray-800/60 flex items-center justify-center">
              <Phone className="w-10 h-10 text-purple-400" />
            </div>
            <div className="absolute -inset-4 bg-purple-500/20 rounded-full blur-xl opacity-50" />
          </div>

          <h2 className="text-4xl font-bold mb-6 gradient-text">
            Coming Soon: Real-Time AI Voice Therapy
          </h2>
          
          <p className="text-xl text-gray-300 mb-12">
            Experience human-like conversations powered by intelligent voice AI. Natural, empathetic, and available whenever you need support.
          </p>

          <div className="relative glass-card p-8 rounded-2xl">
            <div className="absolute -inset-4 bg-purple-500/20 rounded-2xl blur-3xl opacity-30" />
            
            <div className="relative grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                'Natural Language Processing',
                'Emotion Recognition',
                'Real-time Responses'
              ].map((feature, index) => (
                <div
                  key={index}
                  className="flex items-center gap-3 bg-gray-800/60 p-4 rounded-xl"
                >
                  <Wand2 className="w-5 h-5 text-purple-400" />
                  <span className="text-gray-300">{feature}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};