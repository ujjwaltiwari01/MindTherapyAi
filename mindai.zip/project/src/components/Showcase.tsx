import React from 'react';
import { Bot, BrainCircuit, Sparkles } from 'lucide-react';

export const Showcase = () => {
  return (
    <section id="showcase" className="py-24 relative overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1635070041078-e363dbe005cb?auto=format&fit=crop&q=80')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="absolute inset-0 bg-gray-900/90 backdrop-blur-sm" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="relative">
            <div className="absolute -inset-4 bg-purple-500/20 rounded-3xl blur-3xl opacity-50" />
            <div className="relative glass-card p-8 rounded-2xl">
              <div className="flex items-start gap-4 mb-6">
                <div className="w-10 h-10 rounded-full bg-gray-800/60 flex items-center justify-center">
                  <Bot className="w-6 h-6 text-purple-400" />
                </div>
                <div className="flex-1">
                  <div className="bg-gray-800/60 p-4 rounded-2xl rounded-tl-none mb-4">
                    <p className="text-gray-300">How are you feeling today?</p>
                  </div>
                  <div className="bg-gray-700/60 p-4 rounded-2xl rounded-tr-none">
                    <p className="text-gray-300">I've been feeling anxious about work lately.</p>
                  </div>
                </div>
              </div>
              
              <div className="animate-pulse space-y-2">
                <div className="h-2 bg-purple-500/20 rounded w-3/4" />
                <div className="h-2 bg-purple-500/20 rounded w-1/2" />
              </div>
            </div>
          </div>

          <div>
            <h2 className="text-4xl font-bold mb-6 gradient-text">
              Experience AI-Powered Therapy
            </h2>
            
            <div className="space-y-6">
              {[
                {
                  icon: BrainCircuit,
                  title: 'Intelligent Analysis',
                  description: 'Our AI understands context and emotions to provide personalized support.',
                },
                {
                  icon: Sparkles,
                  title: 'Real-Time Insights',
                  description: 'Get immediate feedback and actionable recommendations.',
                },
              ].map((item, index) => {
                const Icon = item.icon;
                return (
                  <div key={index} className="flex items-start gap-4 glass-card p-6 rounded-xl">
                    <div className="w-12 h-12 rounded-xl bg-gray-800/60 flex items-center justify-center shrink-0">
                      <Icon className="w-6 h-6 text-purple-400" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-2 text-white">{item.title}</h3>
                      <p className="text-gray-300">{item.description}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};