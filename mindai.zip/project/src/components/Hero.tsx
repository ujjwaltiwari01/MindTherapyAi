import React from 'react';
import { Brain, ChevronDown } from 'lucide-react';

export const Hero = () => {
  const scrollToFeatures = () => {
    document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gray-900">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1620641788421-7a1c342ea42e?auto=format&fit=crop&q=80')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="absolute inset-0 bg-gray-900/80 backdrop-blur-sm" />
      </div>

      {/* Neural Network Animation */}
      <div className="absolute inset-0 neural-bg opacity-30" />

      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center max-w-4xl mx-auto">
          <div className="mb-8 relative">
            <Brain className="w-24 h-24 mx-auto text-purple-400 animate-float" />
            <div className="absolute -inset-4 bg-purple-500/20 rounded-full blur-3xl animate-pulse-glow" />
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold mb-6 gradient-text">
            Empowering Your Mind with AI-Driven Therapy
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-300 mb-12">
            Experience mental health support through intelligent, personalized care. 
            Chat today, call tomorrow, heal forever.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <a 
              href="#contact" 
              className="px-8 py-4 bg-gradient-to-r from-purple-600 to-cyan-600 rounded-full text-lg font-semibold hover:shadow-lg hover:shadow-purple-500/30 transition-all duration-300 transform hover:-translate-y-1"
            >
              Start Your Journey
            </a>
            <button 
              onClick={scrollToFeatures}
              className="glass-button px-8 py-4 rounded-full text-lg font-semibold"
            >
              Learn More
            </button>
          </div>
        </div>

        <button 
          onClick={scrollToFeatures}
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce text-purple-400 hover:text-purple-300 transition-colors"
        >
          <ChevronDown className="w-8 h-8" />
        </button>
      </div>
    </div>
  );
};